
public class GameMode {

}
